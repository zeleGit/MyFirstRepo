

SELECT C.path AS 'ReportPath',
C.name AS 'ReportName',
u.username AS 'SubOwner'
FROM dbo.ReportSchedule RS 
JOIN msdb.dbo.sysjobs jobs
    ON CONVERT(varchar(36), RS.ScheduleID) = jobs.name
INNER JOIN dbo.Subscriptions S
    ON RS.SubscriptionID = S.SubscriptionID
INNER JOIN dbo.Catalog C
    ON s.report_oid = C.itemid
INNER JOIN dbo.users u 
  on u.UserID = S.OwnerID 
 where u.UserName LIKE '%atacafaz%'

  select * from users 
  where UserName LIKE '%atacafaz%'

/* 

 DECLARE @Oldownerid uniqueidentifier,
         @Newownerid uniqueidentifier; 
   
  SELECT @Oldownerid = '35946FDE-9B08-4F35-8D5E-9AD6AE1B339C', 
         @Newownerid = 'A399DA3F-9D94-4DF1-A62C-2767C5079FC4'  

 update Schedule 
  set CreatedById = @Newownerid
  WHERE CreatedById = @Oldownerid 

 update Catalog 
  set CreatedById = @Newownerid,
      ModifiedByID =  @Newownerid 
  WHERE CreatedById = @Oldownerid 
    OR ModifiedByID = @Oldownerid 
   
 update Subscriptions 
  set OwnerId = @Newownerid,
      ModifiedByID =  @Newownerid 
  WHERE OwnerID = @Oldownerid 
    OR ModifiedByID = @Oldownerid 
  
 update PolicyUserRole 
  set UserID = @Newownerid  
  WHERE UserID = @Oldownerid 

  */
    
  DECLARE @ownerid uniqueidentifier; 
  SET @ownerid = '35946FDE-9B08-4F35-8D5E-9AD6AE1B339C' 

  select * from Catalog  WHERE CreatedById = @ownerid  OR ModifiedByID = @ownerid 
  select * FROM Subscriptions WHERE OwnerID = @ownerid OR ModifiedByID = @ownerid 
  select *  FROM Schedule WHERE CreatedById = @ownerid 
  select *  FROM PolicyUserRole WHERE UserID = @ownerid
  select *  FROM Users WHERE UserID = @ownerid

 -- DELETE FROM Users WHERE UserID = '35946FDE-9B08-4F35-8D5E-9AD6AE1B339C' 

