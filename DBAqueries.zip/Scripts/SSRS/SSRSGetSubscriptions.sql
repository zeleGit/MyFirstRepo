

-- SELECT * FROM SUBSCRIPTIONS WHERE SubscriptionID = '9960AD4A-A862-4A62-8628-21C4C4C4B40C'


SELECT u.UserName, c.Path, Parameters, s.ExtensionSettings, s.Report_OID, SubscriptionID, u.UserID
FROM dbo.[Subscriptions] s
JOIN users u 
on s.OwnerID = u.UserID
JOIN catalog c
on c.ItemID = s.Report_OID
--WHERE Path LIKE '%Cash%Deposit%'
--   OR Path LIKE '%GB_Premium_Allocation_subscription'
--   OR Path LIKE '%LockBoxAdjustmentsCombinedBatch_subscription'
WHERE s.SubscriptionID = 'ad1ee18a-e2b2-4778-a827-7affd8e645ff'
--WHERE s.SubscriptionID = '6f7fca99-83f2-4e15-9d7c-81e72f549b0b'
--WHERE s.SubscriptionID = 'c1d6e71f-c738-41fe-aff9-3e8b058de875'



/*
DECLARE @Default_User varchar(50) 
-- select * from users where username like 'amwins\%hay%' order by username

SELECT @Default_User = UserID FROM dbo.Users WHERE UserName = 'AMWINS\hayesdre'
--SELECT @Default_User = UserID FROM [SourceServer].ReportServer.dbo.Users WHERE UserName = '[amwins\rutkoleo]'

IF OBJECT_ID('tempdb..Subscriptions', 'U') IS NOT NULL 
BEGIN
   drop table tempdb..Subscriptions 
END
IF OBJECT_ID('tempdb..Schedule', 'U') IS NOT NULL 
BEGIN
   drop table tempdb..Schedule 
END
IF OBJECT_ID('tempdb..ReportSchedule', 'U') IS NOT NULL 
BEGIN
   drop table tempdb..ReportSchedule 
END
IF OBJECT_ID('tempdb..Users', 'U') IS NOT NULL 
BEGIN
   drop table tempdb..Users 
END
IF OBJECT_ID('tempdb..Catalog', 'U') IS NOT NULL 
BEGIN
   drop table tempdb..Catalog 
END

SELECT * INTO tempdb..Subscriptions FROM Subscriptions where 1=2 
SELECT * INTO tempdb..Schedule FROM Schedule where 1=2 
SELECT * INTO tempdb..ReportSchedule FROM ReportSchedule where 1=2 
SELECT * INTO tempdb..Users FROM Users  
SELECT * INTO tempdb..Catalog FROM Catalog  

--INSERT INTO [TargetServer].ReportServer.dbo.Subscriptions(
INSERT INTO tempdb..Subscriptions(
    SubscriptionID, OwnerID, Report_OID,  Locale, InactiveFlags, ExtensionSettings, ModifiedByID, ModifiedDate, 
    [Description], LastStatus, EventType, MatchData, LastRunTime, [Parameters], DataSettings, DeliveryExtension, Version, ReportZone
    )
SELECT 
    --cSource.Path,
    --uSource.UserName,
    SubscriptionID,
    --u.UserName,
    --LastStatus,
    COALESCE(uTarget.UserID, @Default_User) AS OwnerID,
    cTarget.ItemID,
    Locale, InactiveFlags, ExtensionSettings,
    @Default_User AS ModifiedByID,
     GETDATE(),
    sSource.[Description], LastStatus, EventType, MatchData, LastRunTime, [Parameters], DataSettings, DeliveryExtension, Version, ReportZone

FROM dbo.Subscriptions sSource
    LEFT JOIN dbo.Catalog cSource ON cSource.ItemId = sSource.Report_OID
    LEFT JOIN dbo.Users uSource ON sSource.OwnerID = uSource.UserID
    LEFT JOIN dbo.Catalog cTarget ON cTarget.Path = cSource.Path
    LEFT JOIN dbo.Users uTarget ON uTarget.UserName = uSource.UserName
WHERE sSource.SubscriptionID NOT IN 
(
SELECT SubscriptionID FROM tempdb..Subscriptions
)


INSERT INTO tempdb..Schedule
(
ScheduleID, Name, StartDate, Flags, NextRunTime, LastRunTime, EndDate, RecurrenceType, MinutesInterval, DaysInterval, WeeksInterval, DaysOfWeek, DaysOfMonth, [Month], MonthlyWeek, State, LastRunStatus, ScheduledRunTimeout, EventType, EventData, Type, ConsistancyCheck, Path, CreatedById
)
SELECT
ScheduleID, Name, StartDate, Flags, NextRunTime, LastRunTime, EndDate, RecurrenceType, MinutesInterval, DaysInterval, WeeksInterval, DaysOfWeek, DaysOfMonth, [Month], MonthlyWeek, State, LastRunStatus, ScheduledRunTimeout, EventType, EventData, Type, ConsistancyCheck, Path, 
COALESCE(uTarget.UserID, @Default_User) AS CreatedById
FROM dbo.Schedule s
INNER JOIN dbo.Users uSource
ON s.CreatedById = uSource.UserID
LEFT JOIN tempdb..Users uTarget
ON uSource.UserName = uTarget.UserName
WHERE ScheduleID NOT IN (SELECT ScheduleID FROM tempdb..Schedule)


INSERT INTO tempdb..ReportSchedule
(
ScheduleID, ReportID, SubscriptionID, ReportAction
)
SELECT
    rsSource.ScheduleID, cTarget.ItemID, rsSource.SubscriptionID, rsSource.ReportAction
FROM dbo.ReportSchedule rsSource
INNER JOIN tempdb..Schedule sTarget
ON rsSource.ScheduleID = sTarget.ScheduleID
INNER JOIN dbo.Catalog cSource
On cSource.ItemID = rsSource.ReportID
INNER JOIN tempdb..Catalog cTarget
ON cSource.Path = cTarget.Path
LEFT JOIN tempdb..ReportSchedule rsTarget
ON  rsSource.ScheduleID = rsTarget.ScheduleID
AND rsSource.ReportID = rsTarget.ReportID
AND rsSource.SubscriptionID = rsTarget.SubscriptionID
WHERE rsTarget.ReportID IS NULL

--To test if your migration has worked properly, you can execute a statement like this against the target server. The GUID should be a SubscriptionID from the Subscriptions table, ideally for something that will be delivered to your inbox.
--exec [ReportServer].dbo.AddEvent @EventType='TimedSubscription', @EventData='cb38a708-7735-4b5a-8ff3-e03ee1b18edb'

*/
