
-- 2014 - P10HOTEL05\HOTEL05 
-- 2019 - C4HOTEL11\HOTEL11 
-- SQL_SCRUBS_AEU 
-- SQL_SCRUBS_AMLINK 
-- SQL_SCRUBS_HOTEL03 

--  SELECT * FROM ExecutionLogs WHERE Timestart > '2022-09-25 00:00:00.00'

/*
  SELECT r.Name, r.Path, 
         COUNT(*) ExecutionCount
    FROM Reports r  
   INNER JOIN ExecutionLogs el     
      ON r.ReportKey = el.ReportKey    
   WHERE Timestart > '2022-06-01 00:00:00.00'
   GROUP BY r.Name, r.Path 
   ORDER BY r.Name, r.Path  
*/ 

  SELECT r.Name, r.Path, 
         COUNT(*) ExecutionCount,
         MAX(el.TimeStart) LastRun
    FROM Reports r  
   INNER JOIN ExecutionLogs el     
      ON r.ReportKey = el.ReportKey    
   WHERE Timestart > '2022-09-25 00:00:00.00'
   GROUP BY r.Name, r.Path 
   ORDER BY LastRun  DESC, r.Name, r.Path 

