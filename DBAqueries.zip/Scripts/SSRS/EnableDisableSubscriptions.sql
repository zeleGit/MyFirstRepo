

/*
-- Disable old, on PHOTEL05
UPDATE dbo.Subscriptions
SET InactiveFlags = 1
where SubscriptionID in('747BACC2-F4DE-4399-B1F3-9D4507A33B6A')
GO
-- Enable old, on PHOTEL05
UPDATE dbo.Subscriptions
SET InactiveFlags = 0
where SubscriptionID in('747BACC2-F4DE-4399-B1F3-9D4507A33B6A')
GO


-- Enable new, on AWSQLRSPROD01
UPDATE dbo.Subscriptions
SET InactiveFlags = 0
--where SubscriptionID in('506AD958-7B66-4739-B989-ADC28BCBD56D')
--where SubscriptionID in('4645A379-D98D-4E20-A65C-AE62A1047EB4')
where SubscriptionID in('747BACC2-F4DE-4399-B1F3-9D4507A33B6A')
GO

-- Disable new, on AWSQLRSPROD01
UPDATE dbo.Subscriptions
SET InactiveFlags = 1
where SubscriptionID in('747BACC2-F4DE-4399-B1F3-9D4507A33B6A')
GO

select * from subscriptions 
where SubscriptionID in('D7E58580-2D6C-45B1-8739-0C17067D15F8')
     --                   '506ad958-7b66-4739-b989-adc28bcbd56d'
select * from ReportSchedule 
where SubscriptionID in('506AD958-7B66-4739-B989-ADC28BCBD56D')


select j.job_id,j.name,  s.*
from dbo.Subscriptions s
join ReportSchedule r on r.SubscriptionID = s.SubscriptionID
join msdb.dbo.sysjobs j on j.name = convert(sysname, r.ScheduleID)
where s.SubscriptionID in('506AD958-7B66-4739-B989-ADC28BCBD56D') ;

select * from catalog

SELECT b.NAME AS JobName,e.NAME  ,e.path  ,d.description  ,a.SubscriptionID  
   ,laststatus  ,eventtype  ,LastRunTime  ,date_created  ,date_modified  
 FROM dbo.ReportSchedule a  
 JOIN msdb.dbo.sysjobs b 
   ON a.ScheduleID = b.NAME 
 JOIN dbo.ReportSchedule c 
   ON b.NAME = convert(sysname, c.ScheduleID) 
 JOIN dbo.Subscriptions d 
   ON c.SubscriptionID = d.SubscriptionID  
 JOIN dbo.CATALOG e 
   ON d.report_oid = e.itemid  
 WHERE e.NAME = 'LockboxAdjustmentsCombinedBatch_subscription' 
 --  WHERE e.Path = '/AmLink GB Reports/Invoice\LockboxAdjustmentsCombinedBatch_subscription'
 --and b.description = 'This job is owned by a report server process. Modifying this job could result in database incompatibilities. Use Report Manager or Management Studio to update this job.'

*/

--Query to get the Last Status of each Subcription and its OwenerID.
SELECT s.[SubscriptionID] -- Subscription ID
,s.[OwnerID] -- Report Owner
--,s.[Report_OID] -- Report ID
, c.Path -- Report Path
--,rs.ScheduleID as SQLJobName -- Name of Job on SQL Server
,s.[LastStatus] -- Status of last subscription execution.
,s.InactiveFlags -- Enabled\Disabled = 1
,s.[Description] -- Description of the report subscription
,s.[EventType] -- Subscription type
,s.[LastRunTime] -- Last time subscription executed
--,s.[Parameters] -- Parameters used for subscription
,s.[DeliveryExtension] -- How to deliver the subscription
FROM [dbo].[Subscriptions] as s left join dbo.Catalog as c
on c.ItemID = s.Report_OID left join dbo.ReportSchedule as rs
on rs.ReportID = s.Report_OID
--where c.path like '%/AmLink GB Reports/Invoice/LockboxAdjustments%'
where c.path like '%invoicestatusaudit%'
----and s.[Description] = 'Email Delivery'
order by s.LastStatus


/*

   select * from Subscriptions 
    where ExtensionSettings LIKE '%full%'

   SELECT * FROM Users 
   where UserID = '3725377C-D087-474B-B4B7-2B0F1F3866B2'
   ORDER BY UserName 

     SELECT * FROM Users 
   where UserID = 'D7E58580-2D6C-45B1-8739-0C17067D15F8'
   ORDER BY UserName 


   5E4B558D-22C6-439E-8842-7B19F2DB750B
   0x01050000000000051500000043170A323DE3084D833D2B467FC20100

   select * from Subscriptions 
   where OwnerID = '5E4B558D-22C6-439E-8842-7B19F2DB750B'
*/

