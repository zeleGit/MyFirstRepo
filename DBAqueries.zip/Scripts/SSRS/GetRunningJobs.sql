
SELECT JobID, JobType, JobStatus, RequestName, StartDate 
FROM RunningJobs


USE ReportServer;

DECLARE @cutoff DATETIME;
SET @cutoff = DATEADD(minute, -5, GETDATE()); --Five minutes ago

SELECT JobID, JobType, JobStatus, RequestName, StartDate 
FROM RunningJobs
WHERE StartDate < @cutoff --prunes records that haven't run for five minutes yet
ORDER BY StartDate --oldest first
