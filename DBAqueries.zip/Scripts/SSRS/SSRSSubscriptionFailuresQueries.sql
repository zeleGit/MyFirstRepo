--USE ReportServer_AmLink
--GO

SELECT cat.Name AS ReportName, 
       el3.ItemPath AS ReportPath, 
	   el3.InstanceName,  
	   el3.UserName,  
       ISNULL(el3.Parameters, '') AS Parameters, 
	   el3.TimeStart, el3.TimeEnd,
       el3.Status, 
       sub.Description, 
	   sub.LastStatus AS LastReportRunStatus, 
	   LastRunTime AS LastReportRunTime
  FROM dbo.ExecutionLog3 el3
 INNER JOIN dbo.Catalog  cat 
    ON el3.ItemPath = cat.Path  
 INNER JOIN Subscriptions AS sub
    ON cat.ItemID = sub.Report_OID
 WHERE el3.RequestType = 'Subscription'
   AND el3.TimeEnd >= DATEADD(HOUR, -12, CURRENT_TIMESTAMP)
   AND el3.Status NOT IN ('rsSuccess')
 ORDER BY cat.Name, el3.TimeEnd  

 