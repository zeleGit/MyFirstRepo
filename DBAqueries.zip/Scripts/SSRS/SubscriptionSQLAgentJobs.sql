/*
SELECT --sj.name AS [SQL Job Name],
'EXEC dbo.sp_update_job  
    @job_name = N''' + sj.name +''',  
    @enabled = 1 ;  
'
FROM ReportServer_AmLink..Subscriptions s
    INNER JOIN ReportServer_AmLink..Users u
        ON s.OwnerID = u.UserID
    INNER JOIN ReportServer_AmLink..Catalog c
        ON s.Report_OID = c.ItemID
    INNER JOIN msdb..sysjobsteps sjs
        ON sjs.command LIKE '%' + CAST(s.SubscriptionID AS VARCHAR(4000)) + '%'
    INNER JOIN msdb..sysjobs sj
        ON sj.job_id = sjs.job_id
ORDER BY s.LastRunTime;


SELECT sj.name AS [SQL Job Name],
       c.Path,
       c.name,
       s.LastRunTime,
       s.description,
       s.LastStatus,
       u.UserName,
       s.SubscriptionID
FROM ReportServer_AmLink..Subscriptions s
    INNER JOIN ReportServer_AmLink..Users u
        ON s.OwnerID = u.UserID
    INNER JOIN ReportServer_AmLink..Catalog c
        ON s.Report_OID = c.ItemID
    INNER JOIN msdb..sysjobsteps sjs
        ON sjs.command LIKE '%' + CAST(s.SubscriptionID AS VARCHAR(4000)) + '%'
    INNER JOIN msdb..sysjobs sj
        ON sj.job_id = sjs.job_id
--where s.SubscriptionID = '506AD958-7B66-4739-B989-ADC28BCBD56D'
--where s.SubscriptionID = '4645A379-D98D-4E20-A65C-AE62A1047EB4'
--where SubscriptionID = '747BACC2-F4DE-4399-B1F3-9D4507A33B6A'
--ORDER BY s.LastRunTime;
ORDER BY c.name;
*/


SELECT --sj.name AS [SQL Job Name],
       --s.SubscriptionID, 
	   --s.InactiveFlags 
'EXEC msdb.dbo.sp_update_job @job_id=N''' + sj.name +  ',@enabled=0
GO'
FROM ReportServer_AmLink..Subscriptions s
    INNER JOIN ReportServer_AmLink..Users u
        ON s.OwnerID = u.UserID
    INNER JOIN ReportServer_AmLink..Catalog c
        ON s.Report_OID = c.ItemID
    INNER JOIN msdb..sysjobsteps sjs
        ON sjs.command LIKE '%' + CAST(s.SubscriptionID AS VARCHAR(4000)) + '%'
    INNER JOIN msdb..sysjobs sj
        ON sj.job_id = sjs.job_id
 WHERE s.InactiveFlags = 0
ORDER BY sj.name ;

