

SELECT TOP 1000 * FROM[ReportServer].[dbo].[ExecutionLog2]

SELECT TOP 1000 * FROM[ReportServer].[dbo].[ExecutionLog3]