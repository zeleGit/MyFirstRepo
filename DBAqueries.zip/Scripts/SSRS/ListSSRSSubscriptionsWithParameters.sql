
WITH
[Sub_Parameters] AS
    (SELECT 
        [SubscriptionID],
        [Parameters] = CONVERT(XML,[Parameters]),
        [ExtensionSettings] = CONVERT(XML,[ExtensionSettings])
     FROM [Subscriptions]
    )

, [MySubscriptions] AS (
    SELECT --DISTINCT 
        [SubscriptionID],
        [ParameterName] = QUOTENAME(p.value('(Name)[1]', 'nvarchar(max)')),
        [ParameterValue] = ISNULL(p.value('(Value)[1]', 'nvarchar(max)'),p.value('(Field)[1]', 'nvarchar(max)')),
        [ParameterType] = CASE WHEN p.value('(Field)[1]', 'nvarchar(max)') IS NOT NULL THEN 'Query' ELSE 'Static' END
    FROM [Sub_Parameters] sp
    CROSS APPLY [Parameters].nodes('/ParameterValues/ParameterValue') t(p)
    UNION
    SELECT --DISTINCT 
        [SubscriptionID],
        [ExtensionSettingName] = QUOTENAME(e.value('(Name)[1]', 'nvarchar(max)')),
        [ExtensionSettingValue] = ISNULL(e.value('(Value)[1]', 'nvarchar(max)'),e.value('(Field)[1]', 'nvarchar(max)')),
        [ExtensionSettingType] = CASE WHEN e.value('(Field)[1]', 'nvarchar(max)') IS NOT NULL THEN 'Query' ELSE 'Static' END
    FROM [Sub_Parameters] sp
    CROSS APPLY [ExtensionSettings].nodes('/ParameterValues/ParameterValue') t(e)
    )

, [SubscriptionsAnalysis] AS (
    SELECT
        ms.[SubscriptionID],
        ms.[ParameterName],
        ms.[ParameterType],
        [ParameterValue] =
              (SELECT STUFF((SELECT [ParameterValue] + ', ' as [text()] 
               FROM [MySubscriptions] 
               WHERE [SubscriptionID] = ms.[SubscriptionID] 
                   AND [ParameterName] = ms.[ParameterName] FOR XML PATH('')),1, 0, '')+'')
    FROM [MySubscriptions] ms
    GROUP BY ms.[SubscriptionID],ms.[ParameterName],ms.[ParameterType]
    )

SELECT
    s.[SubscriptionID],
    o.[UserName] AS [Owner], 
    c.[Name],
    c.[Path],
    s.[Locale], 
    s.[InactiveFlags], 
    m.[UserName] AS [Modified_by], 
    s.[ModifiedDate], 
    s.[Description], 
    s.[LastStatus], 
    CASE WHEN DATALENGTH(s.[DataSettings]) IS NULL THEN 'False' ELSE 'True' END AS [IsDataDriven],
    s.[EventType], 
    s.[LastRunTime], 
    CASE s.[DeliveryExtension] WHEN 'Report Server Email' THEN 'Email' WHEN 'Report Server FileShare' THEN 'File Drop' ELSE s.[DeliveryExtension] END AS SubscriptionType,
    sa.[ParameterName],
    sa.[ParameterType],
    LEFT(sa.[ParameterValue],LEN(sa.[ParameterValue])-1) as [ParameterValue]
FROM [Subscriptions] s
INNER JOIN [Catalog] AS c ON s.[Report_OID] = c.[ItemID]
LEFT OUTER JOIN [Users] AS o ON s.[OwnerID] = o.[UserID]
LEFT OUTER JOIN [Users] AS m ON s.[ModifiedByID] = m.[Userid]
LEFT OUTER JOIN [SubscriptionsAnalysis] AS sa ON s.[SubscriptionID] = sa.[SubscriptionID];

