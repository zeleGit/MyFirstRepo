


 SELECT
       Name,
       [Path]
       ,[Description]
FROM [dbo].[Catalog]
WHERE [Type] = 2
AND Name LIKE '%Retailer%' 
ORDER BY [Path]

