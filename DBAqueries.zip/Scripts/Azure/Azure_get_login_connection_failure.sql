--https://docs.microsoft.com/en-us/sql/relational-databases/system-catalog-views/sys-event-log-azure-sql-database?view=azuresqldb-current
S
Query1: Query the sys.event_log view
--The following query returns all events that occurred between noon on March 25, 2022 and noon on March 30, 2022 (UTC). By --default, query results are sorted by start_time (ascending order).

SELECT database_name, start_time, end_time, event_category,
	event_type, event_subtype, event_subtype_desc, severity,
	event_count, description
FROM sys.event_log
WHERE start_time >= '2022-03-25 12:00:00'
    AND end_time <= '2022-03-30 12:00:00';  
Query login failures for users


Query2: The following query returns connection failures that are failed logins for users that occurred between 10:00 and 11:00 on March 25, 2022 (UTC).

SELECT database_name, start_time, end_time, event_category,
	event_type, event_subtype, event_subtype_desc, severity,
	event_count, description
FROM sys.event_log
WHERE event_type = 'connection_failed'
    AND event_subtype = 4
    AND start_time >= '2022-03-25 10:00:00'
    AND end_time <= '2022-03-25 11:00:00';  