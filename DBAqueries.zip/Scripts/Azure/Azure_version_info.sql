--Database compatibility (e.g. 150 = SQL 2019 or Azure SQL 12)
SELECT name, compatibility_level FROM sys.databases;

--versions
select @@VERSION as Version

--Product version and edition
select serverproperty('ProductVersion') as [version],serverproperty('Edition') as [edition], 
case serverproperty('EngineEdition') 
when 2 then 'Standard'
when 3 then 'Enterprise'
when 4 then 'Express'
when 5 then 'Azure SQL database'
when 6 then 'Azure synapse analytics'
when 8 then 'Azure SQL managed instance'
when 9 then 'Azure SQL Edge'
when 11 then 'Azure synaplse serverless' else 'other' end as EngineEdition

Example:
--In this example SQL server 2019 and Azure SQL Azure 12 have the same database compatibility level: 150
--Microsoft SQL Server 2019 (RTM) - 15.0.2000.5 (X64)   Sep 24 2019 13:48:23   Copyright (C) 2019 Microsoft Corporation  Developer Edition (64-bit) on Windows 10 Enterprise 10.0 <X64> (Build 19044: ) 
--Microsoft SQL Azure (RTM) - 12.0.2000.8   May 12 2022 23:11:24   Copyright (C) 2022 Microsoft Corporation 