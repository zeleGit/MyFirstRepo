--Query 1: List AG Replica roles on the current instance
--returns all replica for primary AGs and returns one row for each secondary AG hosted on the current instance
SELECT  g.name as ag_name,
                              r.replica_server_name,
                              s.role_desc,
                              s.synchronization_health_desc as health_state 
FROM sys.dm_hadr_availability_replica_states s
JOIN sys.availability_groups g
ON s.group_id = g.group_id
JOIN sys.availability_replicas r
ON r.replica_id = s.replica_id
 
-- Alternatively, this query lists all replicas (Note that for primary AGs on the instance there will be duplicate row one for PRIMAY role and one for SECONDARY)
-- Helps to see all replicas from any replica server/instance
--SELECT DISTINCT n.group_name,
--                             n.replica_server_name,
--                              n.node_name,rs.role_desc
--FROM sys.dm_hadr_availability_replica_cluster_nodes n
--JOIN sys.dm_hadr_availability_replica_cluster_states cs
--ON n.replica_server_name = cs.replica_server_name
--JOIN sys.dm_hadr_availability_replica_states rs
--ON rs.replica_id = cs.replica_id
--ORDER BY n.group_name
 
 
--Query 2: AG level health state.
SELECT ag.name
     , hadrARCS.replica_server_name
     , hadrARS.is_local --returns 1 for local AGs (whether primary or seconday AG) hosted on the server this query runs on.
     , hadrARS.role_desc
     , hadrARS.operational_state_desc
     , hadrARS.connected_state_desc
     , hadrARS.recovery_health_desc
     , hadrARS.synchronization_health_desc
     , hadrARCS.join_state_desc
FROM sys.dm_hadr_availability_replica_states AS hadrARS
JOIN sys.dm_hadr_availability_replica_cluster_states AS hadrARCS
ON hadrARS.replica_id = hadrARCS.replica_id
JOIN sys.availability_groups AS ag
ON hadrARS.group_id = ag.group_id;
--WHERE hadrNIM.ag_name like '<AG_name>'
 
--Alternative
SELECT DISTINCT
               ag.name AS 'AGName'
               ,cs.replica_server_name AS 'Replicas'
               ,gs.primary_replica AS 'PrimaryReplica'
               ,rs.role_desc AS 'ReplicaRole'
               ,ar.availability_mode_desc AS 'AvailabilityMode'
               ,ar.failover_mode_desc AS 'FailoverMode'
               ,gs.synchronization_health_desc AS 'HealthState'
FROM sys.availability_groups ag
JOIN sys.dm_hadr_availability_group_states gs
ON ag.group_id = gs.group_id
JOIN sys.dm_hadr_availability_replica_cluster_states cs
ON gs.group_id = cs.group_id
JOIN sys.availability_replicas ar
ON ar.replica_id = cs.replica_id
JOIN sys.dm_hadr_availability_replica_states rs
ON rs.replica_id = cs.replica_id
JOIN sys.dm_hadr_database_replica_states drs
ON drs.group_id = rs.group_id
--WHERE (gs.primary_replica = @@SERVERNAME --returns info for primary AGs only (ignores any secondary AG info)
--or gs.primary_replica is null)
ORDER BY AGName
 
 
--Query 3: Database level health state.
 
--Note: If is_local returns both 0 and 1 for a given database then the server the query is running is the PRIMARY server for the DB.
--Note: If synchronization_state_desc is NOT SYNCHRONIZING then there is issue the seconday server connecting the primary, or data movement suspended or it is in failover transition state.
--NOte: If synchronization_state_desc is either REVERTING or INITIALIZING then the seconday server is in the process of applying UNDO logs from         primary. DO NOT FAILOVER!!!! wait until UNDO completes
--Note: Synchronization_state_desc should be SYNCHRONIZED for synchronous commit or (SYNCHRONIZED - Pri & SYNCHRONIZING - Sec) for asynchronous commit
 
SELECT distinct hadrAG.name
     , hadrARCS.replica_server_name
     , hadrDRCS.[database_name]
     , hadrDRS.is_local
     , hadrDRS.synchronization_state_desc
     , hadrDRS.synchronization_health_desc
     , hadrDRS.database_state_desc
     , hadrDRS.is_suspended
     , hadrdrs.suspend_reason -- 1 = suspended
     , hadrDRS.suspend_reason_desc
     , hadrDRS.last_sent_time
     , hadrDRS.last_received_time
     , hadrDRS.last_hardened_time
     , hadrDRS.last_redone_time
     , hadrDRS.last_commit_time
     , hadrDRS.log_send_queue_size
     , hadrDRS.log_send_rate
FROM sys.dm_hadr_database_replica_states AS hadrDRS
JOIN sys.availability_groups AS hadrAG
ON hadrDRS.group_id = hadrAG.group_id
JOIN sys.dm_hadr_database_replica_cluster_states AS hadrDRCS
ON hadrDRS.group_database_id = hadrDRCS.group_database_id
JOIN sys.dm_hadr_availability_replica_cluster_states AS hadrARCS
ON hadrDRS.replica_id = hadrARCS.replica_id
ORDER BY hadrAG.name
     , hadrDRCS.[database_name]
     , hadrDRS.is_local;
 
--Query4: Failover readyness test.
 
SELECT
    ag.name,
    ar.replica_server_name,
    ars.role_desc,
    ar.availability_mode_desc as [availability_mode],
    ars.synchronization_health_desc as replica_sync_state,
    rcs.database_name,
    drs.synchronization_state_desc as db_sync_state,
    (case rcs.is_failover_ready when 1 then 'True' else 'False' end) as is_failover_ready,
    rcs.is_pending_secondary_suspend,
    rcs.is_database_joined
FROM sys.dm_hadr_database_replica_cluster_states as rcs
JOIN sys.availability_replicas as ar
on ar.replica_id = rcs.replica_id
JOIN sys.dm_hadr_availability_replica_states as ars
on ars.replica_id = ar.replica_id
JOIN sys.dm_hadr_database_replica_states as drs
on drs.group_database_id = rcs.group_database_id
and drs.replica_id = ar.replica_id
JOIN sys.availability_groups as ag
on ag.group_id = ar.group_id
 
 
--Query 5: Query synchronization lag and estimated completion time (RTO)
--For  primary AG running on the server this query runs on, it returns lag info for all secondary instances & databases in addition to one row per secondary AGs hosted on the server
--RTO is equal to either [estimated_recovery_time_seconds] or [estimated_recovery_time_minutes]
 
USE master
GO
SELECT
               cs.replica_server_name,  rs.is_primary_replica, ag.name as AG_name,
               CAST(DB_NAME(rs.database_id)as VARCHAR(40)) as database_name, 
               Convert(VARCHAR(20),rs.last_commit_time,22) as last_commit_time
               ,redo_queue_size --NULL for primary replica
               ,redo_rate --NULL for primary replica
,CONVERT(VARCHAR(20),DATEADD(mi,(rs.redo_queue_size/rs.redo_rate/60.0),GETDATE()),22) estimated_completion_time
               ,CAST((rs.redo_queue_size/rs.redo_rate/60.0) as decimal(10,2)) [estimated_recovery_time_minutes]
               ,(rs.redo_queue_size/rs.redo_rate) [estimated_recovery_time_seconds] 
               ,CONVERT(VARCHAR(20),GETDATE(),22) [current_time] 
FROM sys.dm_hadr_database_replica_states rs
JOIN sys.availability_groups ag
ON rs.group_id = ag.group_id
JOIN sys.dm_hadr_availability_replica_cluster_states cs
ON rs.replica_id = cs.replica_id
WHERE ag.name = 'AG-Acct' --change AG name comment out
--and rs.last_redone_time is not null
ORDER BY DB_NAME(database_id)

--Alternative to see log_send_queue_size & redo_queue_size to see if lag exists
SELECT
ag.name AS [availability_group_name]
, d.name AS [database_name]
, ar.replica_server_name AS [replica_instance_name]
, drs.truncation_lsn
, drs.log_send_queue_size
, drs.redo_queue_size
FROM
sys.availability_groups ag
INNER JOIN sys.availability_replicas ar
ON ar.group_id = ag.group_id
INNER JOIN sys.dm_hadr_database_replica_states drs
ON drs.replica_id = ar.replica_id
INNER JOIN sys.databases d
ON d.database_id = drs.database_id
WHERE drs.is_local = 0--when is_local = 1 query returns one row for each primary and secondary AGs hosted on this instance. 
                      --when is_local = 0 query returns one row for each remote seconday replica for every primary AG hosted on this instance (i.e. no row returned if only seconday AGs hosted on the instance) 
ORDER BY
ag.name ASC, d.name ASC, drs.truncation_lsn ASC, ar.replica_server_name ASC
 
 
--Query 6: Query synchronization lag  (RPO)
--compare or datediff to get the lag between primary last_commit_time (ie. is_local = 1) with each secondary DB (ie. is_local =0) for each db in the AG
 
SELECT ag.name, db_name(rs.database_id) as DBName,
                              rs.is_local,
                              rs.last_commit_time
FROM sys.dm_hadr_database_replica_states rs
JOIN sys.availability_groups ag on rs.group_id = ag.group_id
WHERE ag.name = '<AG_name>'
 
 
--Query 7: Transaction log growth with log_reuse_wait_desc = Availability_replica. May indicate seconday doesn't keep up with applying log
 
SELECT hadrARCS.replica_server_name
     , hadrDRCS.database_name
FROM sys.dm_hadr_database_replica_cluster_states AS hadrDRCS
JOIN sys.dm_hadr_availability_replica_cluster_states AS hadrARCS
    ON hadrDRCS.replica_id = hadrARCS.replica_id
JOIN
    (
        SELECT group_database_id
        FROM sys.dm_hadr_database_replica_states
        WHERE is_local = 0
                AND synchronization_state_desc != 'SYNCHRONIZED'
    ) AS hadrDRS
ON hadrDRCS.group_database_id = hadrDRS.group_database_id
JOIN sys.databases AS D
    ON hadrDRCS.database_name = D.name
WHERE D.log_reuse_wait_desc = 'AVAILABILITY_REPLICA'
     AND hadrDRCS.is_database_joined = 1;

--Query 8. Check if HADR_DATABASE_WAIT_FOR_TRANSITION_TO_VERSIONING wait blocking read on secondary replica
--https://techcommunity.microsoft.com/t5/core-infrastructure-and-security/alwayson-availability-groups-wait-type-hadr-database-wait-for/ba-p/371476

select trn.name as tran_name, trn.transaction_begin_time
, duration =
    ISNULL(NULLIF(CONVERT(varchar(100), DATEDIFF(dd,0, GETDATE() - trn.transaction_begin_time)), 0) + 'd,', '')
    + CONVERT(varchar(100), GETDATE() - trn.transaction_begin_time, 114)
, strn.session_id
, t.event_info as inputbuffer
, ses.program_name
, ses.host_name
, ses.login_name
, ses.host_process_id
from sys.dm_tran_active_transactions as trn
left join sys.dm_tran_session_transactions AS strn on trn.transaction_id = strn.transaction_id
outer apply sys.dm_exec_input_buffer(strn.session_id, default) as t
left join sys.dm_exec_sessions as ses on strn.session_id = ses.session_id
where trn.transaction_begin_time < DATEADD(minute, -10, GETDATE()) -- set to time before secondary became readable
order by transaction_begin_time asc