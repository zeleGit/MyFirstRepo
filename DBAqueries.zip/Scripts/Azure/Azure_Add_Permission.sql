--create login
CREATE LOGIN srv_api_gateway_prod WITH PASSWORD=N'get password from Thycotic'
GO

--create user
CREATE USER srv_api_gateway_prod FOR LOGIN srv_api_gateway_prod WITH DEFAULT_SCHEMA=[dbo]
GO

--add user to role
ALTER ROLE  [db_datareader] ADD MEMBER srv_api_gateway_prod
GO
--Grant role for Azure SQL pool of databases
EXEC sp_addrolemember 'db_datareader', 'srv_api_gateway_prod';
--drop user [srv_api_gateway_dev]

--create login
CREATE LOGIN [srv_api_gateway_dev] WITH PASSWORD=N'get password from thycotic'
GO

--create user
CREATE USER [srv_api_gateway_dev] FOR LOGIN [srv_api_gateway_dev] WITH DEFAULT_SCHEMA=[dbo]
GO

--add user to role
ALTER ROLE  [db_datareader] ADD MEMBER [srv_api_gateway_dev]
GO
--Grant role for Azure SQL pool of databases
EXEC sp_addrolemember 'db_datareader', 'srv_api_gateway_dev';
--drop user [srv_api_gateway_dev]




