--Run against HOTEL11 instance & TechnologyInventory database

--Query 1: Retrieve specific job information  

SELECT abj.ABJobID, abj.JobName, abj.FullPath, abi.ExecutionDateTime,  
       abi.CompletionDateTime, abi.Runtime, abi.TotalSeconds   
FROM ABJobs abj  
INNER JOIN ABInstances abi  
ON abj.ABJobID = abi.ABJobID  
WHERE abj.Scheduler = 'AWPRODAB' 
AND abj.JobName LIKE 'Dashboard Load'  
ORDER BY CompletionDateTime DESC

--Query 2: Retrieve avg for last 7 days  

SELECT abj.JobName, abj.FullPath, AVG(abi.TotalSeconds) AVGSeconds 
FROM ABJobs abj  
INNER JOIN ABInstances abi  
ON abj.ABJobID = abi.ABJobID  
WHERE abj.Scheduler = 'AWPRODAB'   
AND abj.JobName = 'Dashboard Load'  
AND abi.CompletionDateTime >= DATEADD(DAY,-7,CURRENT_TIMESTAMP) 
GROUP BY abj.JobName, abj.FullPath 