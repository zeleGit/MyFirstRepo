--Change to appropriate database and sproc name
--This doesn't execute sproc! The script mark the sproc to recompile and update its plan on next execution.
USE <database name>
GO  
EXEC sp_recompile N'schema.sproc_name';   
GO

--This script executes the sproc and recompiles it
USE <database name>
GO  
EXECUTE <schema.sproc_name> WITH RECOMPILE;  
GO
