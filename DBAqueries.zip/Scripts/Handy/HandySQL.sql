--Query 1:Active requests (with query plans)
SELECT x.session_id, datediff(ss, x.start_time, getdate()) as 'RunDuration(Sec)',
               getdate() as CurrentTime,  status, x.host_name,  x.login_name, x.wait_type, x.wait_resource, x.program_name,
               x.wait_time, x.start_time, x.totallogical_reads , x.totalWrites, x.totalCPU, x.writes_in_tempdb, parallelquery,
    ( SELECT    substring(text, (statement_start_offset/2)+1
                , ((case statement_end_offset  when -1 then datalength(text) else statement_end_offset end - statement_start_offset)/2) + 1)
        FROM sys.dm_exec_sql_text(x.sql_handle) FOR XML PATH(''), TYPE
    ) AS statement_text,
        COALESCE(x.blocking_session_id, 0) AS blocking_session_id,
    (SELECT   p.text FROM (SELECT MIN(sql_handle) AS sql_handle
      FROM sys.dm_exec_requests r2 WHERE r2.session_id = x.blocking_session_id
        ) AS r_blocking
        CROSS APPLY  ( SELECT text AS [text()]
        FROM sys.dm_exec_sql_text(r_blocking.sql_handle) FOR XML PATH(''), TYPE
        ) p (text)) AS blocking_text,
    (SELECT text AS [text()] FROM sys.dm_exec_sql_text(x.sql_handle)
     FOR XML PATH(''), TYPE ) AS sql_text, DB_NAME(x.database_id) as Database_name
 
               --uncomment below to get query plan
    ,(SELECT  query_plan  FROM sys.dm_exec_query_plan(x.plan_handle)   ) AS query_plan
 
FROM
(    SELECT  r.session_id,r.status, s.host_name, s.login_name, r.start_time, r.sql_handle, wait_type,
                              wait_resource, wait_time, s.program_name, statement_start_offset, statement_end_offset, r.blocking_session_id, r.plan_handle,
                              count(*) AS parallelquery,  SUM(CONVERT(BIGINT,r.logical_reads) ) AS totallogical_reads ,
        SUM(CONVERT(BIGINT,r.writes)) AS totalWrites,SUM(convert(bigint,r.cpu_time)) AS totalCPU,
        SUM(CONVERT(BIGINT,tsu.user_objects_alloc_page_count) + CONVERT(BIGINT,tsu.internal_objects_alloc_page_count)) AS writes_in_tempdb,
                              r.database_id
    FROM  sys.dm_exec_requests r
    JOIN sys.dm_exec_sessions s ON s.session_id = r.session_id
    JOIN sys.dm_db_task_space_usage tsu ON s.session_id = tsu.session_id and r.request_id = tsu.request_id
    WHERE r.status IN ('running', 'runnable', 'suspended')
               AND r.session_id > 50
               AND r.session_id != @@spid
    GROUP BY  r.session_id, r.status, s.host_name, s.login_name, r.start_time, r.sql_handle, wait_type,
                              wait_resource, wait_time, statement_start_offset, statement_end_offset, r.blocking_session_id,
                              r.database_id, r.plan_handle, s.program_name
)  x
--order by totalCPU desc 

--Query 2: All sessions activity monitor (with lead blocker - if exists)
SELECT   
	[Session ID]    = s.session_id,   
	[User Process]  = CONVERT(CHAR(1), s.is_user_process),   
	[Login]         = s.login_name,     
	[Database]      = ISNULL(db_name(r.dbid), N''),   
	[Task State]    = ISNULL(t.task_state, N''),   
	[Command]       = ISNULL(r.cmd, N''),   
	[Application]   = ISNULL(s.program_name, N''),   
	[Wait Time (ms)]     = ISNULL(w.wait_duration_ms, 0),   
	[Wait Type]     = ISNULL(w.wait_type, N''),   
	[Wait Resource] = ISNULL(w.resource_description, N''),   
	[Blocked By]    = ISNULL(CONVERT (varchar, w.blocking_session_id), ''),   
	[Head Blocker]  =        
		CASE            -- session has an active request, is blocked, but is blocking others           
		 WHEN r2.session_id IS NOT NULL AND r.blocked = 0 THEN '1'            -- session is idle but has an open tran and is blocking others            
		 WHEN r.spid IS NULL THEN '1'            
		 ELSE ''        
		 END,   
	[Total CPU (ms)] = s.cpu_time,   
	[Total Physical I/O (MB)]   = (s.reads + s.writes) * 8 / 1024,   
	[Memory Use (KB)]  = s.memory_usage * 8192 / 1024,   
	[Open Transactions] = ISNULL(r.open_tran,0),   
	[Login Time]    = s.login_time,   
	[Last Request Start Time] = s.last_request_start_time,   
	[Host Name]     = ISNULL(s.host_name, N''),   
	[Net Address]   = ISNULL(c.client_net_address, N''),   
	[Execution Context ID] = ISNULL(t.exec_context_id, 0),   
	[Request ID] = ISNULL(r.request_id, 0),   
	[Workload Group] = N'' 
	FROM sys.dm_exec_sessions s 
	LEFT OUTER JOIN sys.dm_exec_connections c ON (s.session_id = c.session_id)
	LEFT OUTER JOIN sys.sysprocesses r ON (s.session_id = r.spid)
	LEFT OUTER JOIN sys.dm_os_tasks t ON (r.spid = t.session_id AND r.request_id = t.request_id)
	LEFT OUTER JOIN(    
	-- In some cases (e.g. parallel queries, also waiting for a worker), one thread can be flagged as    
	-- waiting for several different threads.  This will cause that thread to show up in multiple rows    
	-- in our grid, which we don't want.  Use ROW_NUMBER to select the longest wait for each thread,    
	-- and use it as representative of the other wait relationships this thread is involved in.    
	SELECT *, ROW_NUMBER() OVER (PARTITION BY waiting_task_address ORDER BY wait_duration_ms DESC) AS row_num    FROM sys.dm_os_waiting_tasks) w 
	ON (t.task_address = w.waiting_task_address) AND w.row_num = 1
	LEFT OUTER JOIN sys.dm_exec_requests r2 ON (r.spid = r2.blocking_session_id)
	WHERE s.login_name not in ('sa','NT AUTHORITY\SYSTEM') 