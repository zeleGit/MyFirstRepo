EXEC sp_MSForEachDb '
USE [?]
IF ''?'' NOT IN (''master'', ''model'', ''msdb'', ''tempdb'', ''Distribution'')
IF ((SELECT DATABASEPROPERTYEX(''?'', ''Updateability''))=''read_write''  )
BEGIN
DECLARE @CommandTable TABLE
        (
		 Number INT IDENTITY(1,1),
         ExecStmt VARCHAR(MAX)
		)
/* Gather information to drop and then recreate the current foreign key constraints  */
INSERT  @CommandTable
		SELECT   
		''USE '' + QUOTENAME(DB_NAME()) + '';UPDATE STATISTICS '' + QUOTENAME(SCHEMA_NAME(obj.schema_id)) + ''.''
		+ QUOTENAME(obj.name) + '' '' + QUOTENAME(stat.name) + ''WITH FULLSCAN, MAXDOP=0;'' AS the_fix_just_bad_stat
		FROM        sys.objects AS obj
		INNER JOIN  sys.stats AS stat ON stat.object_id = obj.object_id
		CROSS APPLY sys.dm_db_stats_properties(stat.object_id, stat.stats_id) AS sp
		WHERE       obj.is_ms_shipped IN(0,1)
			AND ((rows_sampled* 100 / [rows]) < 100 OR DATEDIFF(hour,last_updated,GETDATE()) > 24)
			--AND (modification_counter* 100 / [rows]) > 10
			--AND modification_counter >0
			AND [rows]  > 0
			--AND OBJECT_SCHEMA_NAME(obj.object_id) SchemaName = ''AccessLetters''
			--AND obj.name = ''al_zipcode''
			--AND DATEDIFF(hour,last_updated,GETDATE()) > 0
			--AND obj.name = ''algb_subscriber''
			AND obj.name NOT LIKE ''%#%''
		ORDER BY modification_counter ASC
		--ORDER BY last_updated ASC
		--ORDER BY obj.name ASC JOIN sys.objects
DECLARE @RemainingCommands VARCHAR(MAX)
DECLARE @ExecStatement NVARCHAR(MAX)

DECLARE Cur1 CURSOR READ_ONLY
FOR
        SELECT  Number , ExecStmt
        FROM    @CommandTable
		ORDER BY Number DESC
OPEN Cur1
FETCH NEXT FROM Cur1 INTO @RemainingCommands , @ExecStatement
WHILE @@FETCH_STATUS = 0
      BEGIN
            PRINT CAST(@RemainingCommands AS VARCHAR) + '' of '' + @ExecStatement
            EXECUTE sp_executesql @ExecStatement
            FETCH NEXT FROM Cur1 INTO @RemainingCommands , @ExecStatement
      END
CLOSE Cur1
DEALLOCATE Cur1
--GO 
END
'






