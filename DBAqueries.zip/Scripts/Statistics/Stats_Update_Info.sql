--Query 1: The following example returns properties of all statistics that exist for the table  
USE <database name>
GO
SELECT sp.stats_id, name, filter_definition, last_updated, rows, rows_sampled, steps, unfiltered_rows, modification_counter   
FROM sys.stats AS stat   
CROSS APPLY sys.dm_db_stats_properties(stat.object_id, stat.stats_id) AS sp  
WHERE stat.object_id = object_id('table_name');


--Query 2: The following example returns all tables, indexed views, and statistics in the current database 
--for which the leading column was modified more than 1000 times since the last statistics update.
USE <database name>

SELECT obj.name, obj.object_id, sp.stats_id, stat.name, filter_definition, last_updated, rows, rows_sampled, steps, unfiltered_rows, modification_counter   
FROM sys.objects AS obj   
INNER JOIN sys.stats AS stat ON stat.object_id = obj.object_id  
CROSS APPLY sys.dm_db_stats_properties(stat.object_id, stat.stats_id) AS sp  
WHERE modification_counter > 1000;

--Query 3: Stats detail on a table
USE <database name>

SELECT stats_id, name AS stats_name,   
    STATS_DATE(object_id, stats_id) AS statistics_date  
FROM sys.stats s  
WHERE s.object_id = OBJECT_ID('schema_name.table_name');  
GO

--Query 4: Update statistics 
--update ALL statistics on a table with FULLSCAN
USE <database name>
GO
UPDATE STATISTICS <schema_name.table_name> WITH FULLSCAN;

--specific statistics
USE <database name>
GO
UPDATE STATISTICS <schema_name.table_name> (<statistics_name>) WITH FULLSCAN;



