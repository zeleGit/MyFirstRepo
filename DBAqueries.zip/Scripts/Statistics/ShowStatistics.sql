DBCC SHOW_STATISTICS(Transactions, 'idx_Transactions_TransactionDate')


